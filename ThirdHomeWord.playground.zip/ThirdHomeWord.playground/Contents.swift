import UIKit

//1
func sum(_ first: Int, _ second: Int) -> Int {
    return first + second
}

print(sum(5, -3))

//2

let tup = (5, "Строка")

func tupleToString(tup: (Int, String)) {
    let strInt = String(tup.0)
    print("Результат приведения числа \(strInt) к типу \(type(of: strInt))")
}

tupleToString(tup: tup)

//3

typealias OptionalVoidCallBack = (() -> Void)?

let callback: OptionalVoidCallBack = {
    print("Второе число больше 0")
}

func checkCallback(checkNumber: Int, callback: OptionalVoidCallBack) {
    if checkNumber > 0 {
        guard let callback = callback else { return }
        callback()
    }
}

checkCallback(checkNumber: 5, callback: callback)

//4

func isLeapYear(year: Int) {
    let answer = year % 4
    if answer == 0 {
        print("\(year) год високосный")
    } else {
        print("\(year) год не високосный")
    }
}

isLeapYear(year: 2020)
